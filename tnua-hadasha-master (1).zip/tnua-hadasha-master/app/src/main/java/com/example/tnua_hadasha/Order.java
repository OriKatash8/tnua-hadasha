package com.example.tnua_hadasha;

public class Order {
    private final String TheOrder;


    public Order(String TheOrder)
    {
        this.TheOrder=TheOrder;
    }
    public String getTheOrder() {
        return TheOrder;
    }



}
